<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "paterolum_refinery_system";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if(isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    

    $sql = "INSERT INTO contacts (name, email, subject, message) VALUES ('$name', '$email' ,'$subject', '$message')";
    if ($conn->query($sql) === TRUE) {
        echo "<p>Thank you for contacting us, $name! We will get back to you soon.</p>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


$conn->close();
?>

    
    

