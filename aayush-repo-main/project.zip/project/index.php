<!DOCTYPE html>
<html>
<head>
  <title>Paterolum Refinery System</title>
  <link rel="style" type="text/css" href="css/style.css">
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="refinary detail.php">Refineries</a></li>
        <li><a href="contect.php">Contact</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="hero">
      <div class="container">
        <h1>Welcome to Paterolum Refinery System</h1>
        <p>Discover the power of our advanced refinery solutions.</p>
        <a href="refinery.php" class="btn">Learn More</a>
      </div>
    </section>

    <section class="features">
      <div class="container">
        <h2>Key Features</h2>
        <ul>
          <li>
            <img src="images/feature1.png" alt="Feature 1">
            <h3>Feature 1</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <img src="images/feature2.png" alt="Feature 2">
            <h3>Feature 2</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <img src="images/feature3.png" alt="Feature 3">
            <h3>Feature 3</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
        </ul>
      </div>
    </section>
  </main>

  <footer>
    <div class="container">
      <p>&copy; <?php echo date("Y"); ?> Paterolum Refinery System. All rights reserved.</p>
    </div>
  </footer>
</body>
</html>
